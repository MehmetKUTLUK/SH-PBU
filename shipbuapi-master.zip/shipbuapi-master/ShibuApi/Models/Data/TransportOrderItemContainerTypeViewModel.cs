﻿namespace ShipbuApi.Models.Data;

public class TransportOrderItemContainerTypeViewModel
{
    public bool Enabled { get; set; }
    public string NameTr { get; set; }
    public string NameEn { get; set; }
    public int DisplayOrder { get; set; }
}
