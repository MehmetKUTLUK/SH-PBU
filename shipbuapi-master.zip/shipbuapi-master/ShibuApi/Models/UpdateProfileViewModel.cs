﻿namespace ShipbuApi.Models
{
    public class UpdateProfileViewModel
    {
        public string Name { get; set; }
    }
}
