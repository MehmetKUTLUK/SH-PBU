﻿namespace ShipbuApi.Models
{
    public class TokenViewModel
    {
        public string UserName { get; set; }

        public string Password { get; set; }
    }
}
