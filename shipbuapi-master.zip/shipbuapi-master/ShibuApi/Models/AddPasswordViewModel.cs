﻿namespace ShipbuApi.Models
{
    public class AddPasswordViewModel
    {
        public string Token { get; set; }
        public string UserId { get; set; }
        public string NewPassword { get; set; }
    }
}
