﻿namespace ShipbuApi;

public class AppApiResponse
{
    public bool Succeded { get; set; }
    public dynamic? Data { get; set; }
    public string? Message { get; set; }
}
