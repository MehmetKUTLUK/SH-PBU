﻿using Microsoft.AspNetCore.Identity;

namespace ShipbuData;

public class Role : IdentityRole<Guid>
{
}
